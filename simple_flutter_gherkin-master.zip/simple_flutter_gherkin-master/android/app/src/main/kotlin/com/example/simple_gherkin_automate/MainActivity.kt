package com.example.simple_gherkin_automate

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
